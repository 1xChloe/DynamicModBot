const { EmbedBuilder } = require('discord.js');
const { sep } = require('path');
const { dkto } = require('dkto.js');
const { EMBED_COLORS } = require('../../constants');
const { create_command } = require('../../handlers/commands');
const config = require('../../../config.json');
const emitter = require('../../utils/events');
const moment = require('moment');
let prebanData;
let banData;

create_command(
	async function (interaction) {
		const embed = new EmbedBuilder()
			.setColor(EMBED_COLORS.BASE)
			.setFooter({ text: `${config.version}` })
			.setTimestamp();

		const message = await interaction.followUp({
			embeds: [embed.setDescription('**Sending ban data request...**')],
		});

		const UserId = interaction.options.getString('player_id', true);

		emitter.emit('sendData', 'requestBanData', { UserId });

		try {
			setTimeout(async function () {
				prebanData = await global.banDataReceived;

				if (prebanData === 'No ban data found')
					return message.edit({
						embeds: [
							embed.setDescription(
								`**No ban data found for** ` + '`' + `${UserId}` + '`'
							),
						],
					});

				banData = JSON.parse(prebanData);

				message.edit({
					embeds: [
						embed
							.setDescription(
								`**Ban Duration: ${
									banData.duration === 'Permenant'
										? 'Permenant'
										: moment.duration(banData.duration, 'hours').days + ' days'
								}**`
							)
							.setThumbnail(interaction.guild.iconURL())
							.addFields(
								{ name: 'Reason', value: `${banData.reason}` },
								{ name: 'Moderator:', value: `${banData.admin}`, inline: true },
								{
									name: 'Appealable:',
									value: `${banData.appeal === true ? 'Appealable' : 'Not Appealable'}`,
									inline: true,
								}
							),
					],
				});
			}, 3000);
		} catch (e) {
			return message.edit({
				embeds: [embed.setColor('Red').setDescription(`**${e}**`)],
			});
		}
	},
	{
		name: __filename.split('.js').shift().split(sep).pop(),
		category: __dirname.split(sep).pop(),
		description: 'Fetches a players ban information',
		options: dkto.builder
			.command_options()
			.string({
				name: 'player_id',
				description: 'ID of the player to fetch ban data from',
				required: true,
			})
			.toJSON(),
	}
);
