const { EmbedBuilder } = require('discord.js');
const { sep } = require('path');
const { dkto } = require('dkto.js');
const { EMBED_COLORS } = require('../../constants');
const { create_command } = require('../../handlers/commands');
const config = require('../../../config.json');
const emitter = require('../../utils/events');

create_command(
	async function (interaction) {
		const embed = new EmbedBuilder()
			.setColor(EMBED_COLORS.BASE)
			.setFooter({ text: `${config.version}` })
			.setTimestamp();

		const message = await interaction.followUp({
			embeds: [embed.setDescription('**Sending unban request...**')],
		});

		const UserId = interaction.options.getString('player_id', true);

		emitter.emit('sendData', 'unban', { UserId });

		message.edit({
			embeds: [embed.setDescription(`**Successfully sent unban request**`)],
		});
	},
	{
		name: __filename.split('.js').shift().split(sep).pop(),
		category: __dirname.split(sep).pop(),
		description: 'Unbans a player in game',
		options: dkto.builder
			.command_options()
			.string({
				name: 'player_id',
				description: 'ID of the player to unban',
				required: true,
			})
			.toJSON(),
	}
);
