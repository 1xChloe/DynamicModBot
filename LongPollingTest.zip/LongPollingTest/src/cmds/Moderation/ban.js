const { EmbedBuilder } = require('discord.js');
const { sep } = require('path');
const { dkto } = require('dkto.js');
const { EMBED_COLORS } = require('../../constants');
const { create_command } = require('../../handlers/commands');
const config = require('../../../config.json');
const emitter = require('../../utils/events');
const ms = require('ms');
let Duration;

create_command(
	async function (interaction) {
		const embed = new EmbedBuilder()
			.setColor(EMBED_COLORS.BASE)
			.setFooter({ text: `${config.version}` })
			.setTimestamp();

		const message = await interaction.followUp({
			embeds: [embed.setDescription('**Sending ban request...**')],
		});

		const Player = interaction.options.getString('player_username', true);
		const Reason =
			interaction.options.getString('reason', false) || 'No Reason Given';
		const givenDuration =
			interaction.options.getString('duration', false) || 'Permenant';
		const Appealable =
			interaction.options.getBoolean('appealable', false) || true;
		const Admin = interaction.user.username;

		if (givenDuration === 'Permenant') {
			Duration = 'Permenant';
		}

		emitter.emit('sendData', 'ban', {
			Player,
			Reason,
			Duration,
			Appealable,
			Admin,
		});

		message.edit({
			embeds: [embed.setDescription(`**Successfully sent ban request**`)],
		});
	},
	{
		name: __filename.split('.js').shift().split(sep).pop(),
		category: __dirname.split(sep).pop(),
		description: 'Bans a player in game',
		options: dkto.builder
			.command_options()
			.string({
				name: 'player_username',
				description: 'Username of the player to ban',
				required: true,
			})
			.string({
				name: 'reason',
				description: 'Reason to ban the player',
				required: false,
			})
			.string({
				name: 'duration',
				description: 'Duration for the ban',
				required: false,
			})
			.boolean({
				name: 'appealable',
				description: 'If the user can appeal',
				required: false,
			})
			.toJSON(),
	}
);
