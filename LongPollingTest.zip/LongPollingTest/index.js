const { Client, dkto } = require('dkto.js');
const emitter = require('./src/utils/events');

const djs = require('discord.js');
const { disconnect } = require('process');
const EmbedBuilder = djs.EmbedBuilder;

djs.EmbedBuilder = class extends EmbedBuilder {
	constructor(data) {
		super(data);
	}

	addField(name, value, inline) {
		this.data.fields = this.data.fields || [];
		this.data.fields.push({ name, value, inline });

		return this;
	}
};

const client = new Client({
	intents: 32767,
	allowedMentions: { parse: ['users', 'roles'], repliedUser: false },
});

dkto.handler.events
	.setOptions({
		hotReload: true,
		relativePath: './src/events',
		client,
	})
	.load();

client.login(require('./config.json').token);

// Polling

global.banDataReceived;

const poll = new (require('roblox-long-polling'))({
	port: 5058,
	password: 'aesthetix',
});

poll.on('connection', (connection) => {
	console.log('[Connected]: ', connection.id);

	connection.on('banDataReceived', (body) => {
		global.banDataReceived = body;
	});

	connection.on('internal_ping', () => {
		console.log(`[Pinged]: ${connection.id}`);
	});

	connection.on('disconnect', () => {
		console.log('[Disconnection]:', connection.id);
	});
});

emitter.on('sendData', async function (name, data) {
	poll.broadcast(name, data);
	console.log(name, data);
});
