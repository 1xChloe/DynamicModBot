const { EmbedBuilder } = require('discord.js');
const { sep } = require('path');
const { dkto } = require('dkto.js');
const { EMBED_COLORS } = require('../../constants');
const config = require('../../../config.json');
const { create_command } = require('../../handlers/commands');
const emitter = require('../../utils/events');

create_command(
	async function (interaction) {
		const embed = new EmbedBuilder()
			.setColor(EMBED_COLORS.BASE)
			.setFooter({ text: `${config.version}` })
			.setTimestamp();

		const message = interaction.options.getString('message', true);

		emitter.emit('sendData', 'sent', message);
		interaction.followUp({
			embeds: [embed.setDescription(`**Successfully sent message through**`)],
		});
	},
	{
		name: __filename.split('.').shift().split(sep).pop(),
		category: __dirname.split(sep).pop(),
		description: 'broadcast',
		options: dkto.builder
			.command_options()
			.string({
				name: 'message',
				description: 'Broadcast message to roblox',
				required: true,
			})
			.toJSON(),
	}
);
