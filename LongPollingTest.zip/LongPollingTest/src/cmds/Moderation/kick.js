const { EmbedBuilder } = require('discord.js');
const { sep } = require('path');
const { dkto } = require('dkto.js');
const { EMBED_COLORS } = require('../../constants');
const { create_command } = require('../../handlers/commands');
const config = require('../../../config.json');
const emitter = require('../../utils/events');

create_command(
	async function (interaction) {
		const embed = new EmbedBuilder()
			.setColor(EMBED_COLORS.BASE)
			.setFooter({ text: `${config.version}` })
			.setTimestamp();

		const message = await interaction.followUp({
			embeds: [embed.setDescription('**Sending kick request...**')],
		});

		const Player = interaction.options.getString('player_username', true);
		const Reason =
			interaction.options.getString('reason', false) || 'No Reason Given';

		emitter.emit('sendData', 'kick', { Player, Reason });

		message.edit({
			embeds: [embed.setDescription(`**Successfully sent kick request**`)],
		});
	},
	{
		name: __filename.split('.js').shift().split(sep).pop(),
		category: __dirname.split(sep).pop(),
		description: 'Kicks a player in game',
		options: dkto.builder
			.command_options()
			.string({
				name: 'player_username',
				description: 'Username of the player to kick',
				required: true,
			})
			.string({
				name: 'reason',
				description: 'Reason to kick the player',
				required: false,
			})
			.toJSON(),
	}
);
